#include "atlas_misc.h"

#if defined(NoChange)
double dsecnd(void)
#elif defined(UPCASE)
double DSECND(void)
#else /* if defined(ADD_) || defined(ADD__) */
double dsecnd_(void)
#endif
{
   return(ATL_cputime());
}
