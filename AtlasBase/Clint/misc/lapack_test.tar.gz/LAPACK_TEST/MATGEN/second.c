#include "atlas_misc.h"

#if defined(NoChange)
float second(void)
#elif defined(UPCASE)
float SECOND(void)
#else /* if defined(ADD_) || defined(ADD__) */
float second_(void)
#endif
{
   return(ATL_cputime());
}
